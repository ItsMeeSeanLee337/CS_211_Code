#include <stdio.h>
#include <stdlib.h>

void print(int** matrixToBePrinted, int k)
{
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j < k; j++)
        {
            printf("%d ", matrixToBePrinted[i][j]);
        }
        printf("\n");
    }
}

int** multiply(int** matrix1, int** matrix2, int** resultMatrix, int k)
{
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j < k; j++)
        {
            resultMatrix[i][j] += matrix1[i][j] * matrix2[i][j];
        }
    }
    return resultMatrix;
}

int main(int argc, char* argv[])
{
    FILE* f = fopen(argv[1], "r");
    if (f == NULL)
    {
        printf("error\n");
    }
    //k is how many rows and columns there are
    int k;
    int power;
    int data;
    //this scans how many rows there are
    fscanf(f, "%d", &k);
    int** originalMatrix = (int**)malloc(k*sizeof(int*));
    int** copyMatrix = (int**)malloc(k*sizeof(int*));
    int** resultMatrix = (int**)malloc(k*sizeof(int*));
    //malloc every row
    for (int i = 0; i < k; i++)
    {
        copyMatrix[i] = (int*)malloc(k*sizeof(int*));
        originalMatrix[i] = (int*)malloc(k*sizeof(int*));
        resultMatrix[i] = (int*)malloc(k*sizeof(int*));
    }
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j < k; j++)
        {
            fscanf(f, "%d", &data);
            originalMatrix[i][j] = data;
            copyMatrix[i][j] = originalMatrix[i][j];
            resultMatrix[i][j] = copyMatrix[i][j];
        }
    }
    //this reads how much we have to multiply
    fscanf(f, "\n%d", &power);
    if (power == 0)
    {
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                if (i == j)
                {
                    originalMatrix[i][j] = 1;
                }
                else
                {
                    originalMatrix[i][j] = 0;   
                }
            }
        }
        print(originalMatrix, k);
    }
    else if (power == 1)
    {
        print(resultMatrix, k);
    }
    else
    {
        for (int i = 0; i < k; i++)
        {
            resultMatrix = multiply(originalMatrix, copyMatrix, resultMatrix, k);
        }
        print(resultMatrix, k);
    }
    for (int i = 0; i < k; i++)
    {
        free(copyMatrix[i]);
        free(originalMatrix[i]);
        free(resultMatrix[i]);
    }
    free(originalMatrix);
    free(copyMatrix);
    free(resultMatrix);
}